ansible -i hosts-11-14 es -m shell -a "/etc/init.d/client_node.sh stop;/etc/init.d/master_node.sh stop"
