ansible -i hosts-15-16 es -m shell -a "/etc/init.d/data_node1.sh start;/etc/init.d/data_node2.sh start;/etc/init.d/data_node3.sh start"
