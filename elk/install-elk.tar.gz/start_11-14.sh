ansible -i hosts-11-14 es -m shell -a "/etc/init.d/client_node.sh start;/etc/init.d/master_node.sh start"
