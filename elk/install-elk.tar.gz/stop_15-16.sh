ansible -i hosts-15-16 es -m shell -a "/etc/init.d/data_node1.sh stop;/etc/init.d/data_node2.sh stop;/etc/init.d/data_node3.sh stop"
